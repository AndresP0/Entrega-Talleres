fun main() {
    val listaPersonas = mutableListOf<Persona>()

    // Registro de datos para 5 usuarios
    repeat(5) { indice ->
        println("Ingrese el peso del usuario ${indice + 1} en kg:")
        val peso = leerNumeroValido("peso")

        println("Ingrese la estatura del usuario ${indice + 1} en metros:")
        val estatura = leerNumeroValido("estatura")

        val persona = Persona(peso, estatura)
        listaPersonas.add(persona)
        println("Usuario ${indice + 1} registrado con éxito.\n")
    }

    // Resumen de usuarios registrados
    println("\nResumen de Usuarios Registrados:")
    listaPersonas.forEach { persona ->
        println(persona.generarResumen())
    }
}

// Función para validar la entrada de números
fun leerNumeroValido(campo: String): Double {
    while (true) {
        val entrada = readLine()
        try {
            val numero = entrada?.toDouble()
            if (numero != null && numero > 0) return numero
            println("Por favor, ingrese un $campo válido (número positivo).")
        } catch (e: Exception) {
            println("Entrada no válida. Intente nuevamente.")
        }
    }
}

// Clase Persona para representar a cada usuario
class Persona(private val peso: Double, private val estatura: Double) {
    private val imc: Double = calcularIMC()
    private val clasificacion: String = determinarClasificacionIMC()

    // Método para calcular el IMC
    private fun calcularIMC(): Double {
        return peso / (estatura * estatura)
    }

    // Método para determinar la clasificación del IMC
    private fun determinarClasificacionIMC(): String {
        return when {
            imc < 16.0 -> "Delgadez severa"
            imc in 16.0..16.99 -> "Delgadez moderada"
            imc in 17.0..18.49 -> "Delgadez leve"
            imc in 18.5..24.99 -> "Normal"
            imc in 25.0..29.99 -> "Preobeso"
            imc in 30.0..34.99 -> "Obesidad leve"
            imc in 35.0..39.99 -> "Obesidad media"
            else -> "Obesidad mórbida"
        }
    }

    // Método para generar un resumen en formato de tarjeta
    fun generarResumen(): String {
        return """
            ----------------------------
            | Peso:           $peso kg |
            | Estatura:       $estatura m |
            | IMC:         
            | Clasificación:  $clasificacion |
            ----------------------------
        """.trimIndent()
    }
}
